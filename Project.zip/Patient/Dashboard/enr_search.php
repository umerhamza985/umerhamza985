<?php
session_start();

if(isset($_SESSION['username'])){

   $userseaching= $_GET["enr_input"];
   ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <title>PRB Project</title>
	
	<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
</head>
<body>
    <div class="wrap">
        <div class="navigation on">
            <a class="nav-open" href="javascript:;">
                <p class="triangle"></p>
            </a>
            <p class="header">Staff Interface</p>
            <span class="name">Welcome,<?php echo $_SESSION['username'] ?></span>
 <div class="btnbox">
                <a class="nav-btn1" href="http://localhost/Patient/Dashboard/dashboard.php">Back To Home</a>
				<a class="nav-btn2" href="../logout.php/">Logout</a>
            </div>
            <a class="nav-btn-back" href="javascrit:;">Back to Main Page</a>
        </div>
        <div class="Mainpart">
            <div class="TrailOrganization-listbox on">
                <h4>Students</h4>
                 <button type="button" class="btn btn-create" data-toggle="modal" data-target="#pop-orglist">
                Create
                </button>
				<form action="dashboard.php" method="post" >
                <div class="input">
                    <p>SearchBox</p>
                    <input type="text" placeholder="Type Here" name="stu_input">
                    <button type="submit" class="btn btn-success" name="stu_search">Search</button>
                </div>
				<b>You have searched: </b><?php echo $userseaching; ?>
				</form>
						<table>
							  <tr>
							  <th>Serial No.</th>
								<th>Name</th>
								<th>Number Member</th>
								<th>Date</th>
								<th>Class</th>
								<th>Status</th>
							  </tr>
							  <?php
							  include_once("../connection.php");
							  $i=0;
							$user_session = $_SESSION['username'];
							  $query ="SELECT * FROM enr Where CONCAT(enr_name,enr_no_member,enr_date,enr_class,enr_status) LIKE '%$userseaching%' and added_by='$user_session'";
                                $result = mysqli_query($db,$query);
								$count = mysqli_num_rows($result);
								if($count > 0){
								while( $orgshow_row = mysqli_fetch_array($result,MYSQLI_ASSOC))

								  {
									  $i++;
							  
							  ?>
							  <tr>
								<td><?php echo $i;?></td>
								<td><?php echo $orgshow_row['enr_name'];?></td>
								<td><?php echo $orgshow_row['enr_no_member'];?></td>
								<td><?php echo $orgshow_row['enr_date'];?></td>
								<td><?php echo $orgshow_row['enr_class'];?></td>
								<td><?php echo $orgshow_row['enr_status'];?></td>
								
							  </tr>
							<?php 
								}
								} else{
									?>
									<tr>
									<td colspan="6"> <?php echo"No Record Found"; ?> </td>
									</tr>
								<?php	
								}?>
							</table>
            </div>


        </div>
    </div>
    <script src="./js/jQuery.js"></script>
    <script src="./js/bootstrap.bundle.min.js"></script>
    <script src="./js/index.js"></script>
	
	

				
				
			
				
				
					
</body>
</html>


<?php
 }else{

	header("Location:../Panel/panel.php");
	
}	?>
