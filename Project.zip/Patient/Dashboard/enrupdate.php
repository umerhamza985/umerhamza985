<?php
session_start();
include_once("../connection.php");
 @$u_enr_id = $_GET['enr_edit'];
if(isset($_SESSION['username'])){

 if($u_enr_id){
 $sql = "SELECT * FROM `enr` WHERE enr_id='$u_enr_id'";
      $result = mysqli_query($db,$sql);
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
			$u_enr_name = $row['enr_name'];
			$u_enr_no_member = $row['enr_no_member'];
			$u_enr_date = $row['enr_date'];
			$u_enr_class = $row['enr_class'];
			$u_enr_status = $row['enr_status'];
 }

   
   ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <title>PRB Project</title>
	
	<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
</head>
<body>
    <div class="wrap">
        <div class="navigation on">
            <a class="nav-open" href="javascript:;">
                <p class="triangle"></p>
            </a>
            <p class="header">Staff Interface</p>
            <span class="name">Welcome,<?php echo $_SESSION['username'] ?></span>
            <div class="btnbox">
                <a class="nav-btn1" href="dashboard.php">Trail Organization</a>
                <a class="nav-btn2" href="dashboard.php">Create Patients</a>
                <a class="nav-btn3" href="dashboard.php">Create Studies</a>
                <a class="nav-btn4" href="dashboard.php">View Enrollment</a>
				<a class="nav-btn4" href="../logout.php/">Logout</a>
            </div>
            <a class="nav-btn-back" href="javascrit:;">Back to Main Page</a>
        </div>
        <div class="Mainpart">
            <div class="TrailOrganization-listbox on">
                <h4 style="font-size:32px">Update Enrollment</h4>
                 <button type="button" class="btn btn-create" data-toggle="modal" data-target="#pop-enrlist">
                Create
                </button>
                <div class="input">
                    <p>SearchBox</p>
                    <input type="text" placeholder name>
                    <a class="Search" href="javascript:;">Search</a>
                </div>
						<form action="enrupdate.php" method="post">
                            <div class="modal-body">
                                <div class="create-patient-name">
								<input type="hidden" name="updated_id" value="<?php echo $u_enr_id;?>">
                                    <p>Name:</p>
                                    <input id="get-name" name="u_enr_name" type="text" placeholder="Enter Name" value="<?php echo $u_enr_name; ?>" >
                                </div>
                               
                                <div class="create-patient-age">
                                    <p>Number of Member:</p>
                                    <input id="get-age" name="u_enr_no_member" type="text" placeholder="Enter Number of member" value="<?php echo $u_enr_no_member; ?>">
                                </div>
                                <div class="create-patient-address">
                                    <p>Date:</p>
                                    <input id="get-address" name="u_enr_date" type="date" placeholder="Enter Address" value="<?php echo $u_enr_date; ?>">
                                </div>
                                <div class="create-patient-details">
                                    <p>Class:</p>
                                    <input id="get-details" name="u_enr_class" type="text" placeholder="Enter Details" value="<?php echo $u_enr_class ; ?>" >
                                </div>
								 <div class="create-patient-gender">
                                    <p>Coures Status:</p>
                                    <select name="u_enr_status" id="get-gender">
										<option value="<?php echo $u_enr_status ; ?>"><?php echo $u_enr_status ; ?></option>
                                        <option value="Complete">Complete</option>
                                        <option value="Incomplete">Incomplete</option>
                                    </select>
                                </div>
                            </div>
                           
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary" name="u_save_enr">Update Now</button>
                        
							</form>
            </div>

    <script src="./js/jQuery.js"></script>
    <script src="./js/bootstrap.bundle.min.js"></script>
    <script src="./js/index.js"></script>
	
	
	
				
					
</body>
</html>


<?php
 }else{

	header("Location:../Panel/panel.php");
	
}	?>

<?php
include_once("../connection.php");
if(isset($_POST['u_save_enr'])) {
 $u_enr_id = $_POST['updated_id'];	
 $u_enr_name = $_POST['u_enr_name'];
 $u_enr_no_member  = $_POST['u_enr_no_member'];
 $u_enr_date  =$_POST['u_enr_date'];
 $u_enr_class  = $_POST['u_enr_class'];
 $u_enr_status   =$_POST['u_enr_status'];

$result = mysqli_query($db, "UPDATE `enr` SET `enr_name`='$u_enr_name',`enr_no_member`='$u_enr_no_member',`enr_date`='$u_enr_date',`enr_class`='$u_enr_class',`enr_status`='$u_enr_status ' WHERE `enr_id`='$u_enr_id'");
echo "<script>alert('Record Updated successfully.')</script>";
echo "<script>window.location.href = 'dashboard.php';</script>";


}

?>
