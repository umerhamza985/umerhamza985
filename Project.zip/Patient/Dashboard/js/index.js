$('.nav-open').on('click', function () {
    if ($('.nav').hasClass('on')) {
      $('.nav').removeClass('on')
    } else {
      $('.nav').addClass('on')
    }
  })

  // $('.nav-btn2').on('click', function () {
  //   if ($('.Patient-listbox').hasClass('on')) {
  //     $('.Study-listbox').removeClass('on')
  //   } else {
  //     $('.Patient-listbox').addClass('on')
  //   }
  // })
  // $('.nav-btn3').on('click', function () {
  //   if ($('.Study-listbox').hasClass('on')) {
  //     $('.Patient-listbox').removeClass('on')
  //   } else {
  //     $('.Study-listbox').addClass('on')
  //   }
  // })
  $('.btnbox>a').click(function(){
    $(this).addClass('on').siblings().removeClass('on');
    $('.Mainpart>div').eq($(this).index()).addClass('on').siblings().removeClass('on');
  })
