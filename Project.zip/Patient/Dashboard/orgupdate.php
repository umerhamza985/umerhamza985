<?php
session_start();
include_once("../connection.php");
 @$u_org_id = $_GET['org_edit'];
if(isset($_SESSION['username'])){

 if($u_org_id){
 $sql = "SELECT * FROM `org` WHERE org_id='$u_org_id'";
      $result = mysqli_query($db,$sql);
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
			$u_org_name = $row['org_name'];
			$u_org_age = $row['org_age'];
			$u_org_details = $row['org_desc'];
 }

   
   ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <title>PRB Project</title>
	
	<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
</head>
<body>
    <div class="wrap">
        <div class="navigation on">
            <a class="nav-open" href="javascript:;">
                <p class="triangle"></p>
            </a>
            <p class="header">Staff Interface</p>
            <span class="name">Welcome,<?php echo $_SESSION['username'] ?></span>
            <div class="btnbox">
                <a class="nav-btn1" href="dashboard.php">Trail Organization</a>
                <a class="nav-btn2" href="javascript:;">Create Patients</a>
                <a class="nav-btn3" href="javascript:;">Create Studies</a>
                <a class="nav-btn4" href="javascript:;">View Enrollment</a>
				<a class="nav-btn4" href="../logout.php/">Logout</a>
            </div>
            <a class="nav-btn-back" href="javascrit:;">Back to Main Page</a>
        </div>
        <div class="Mainpart">
            <div class="TrailOrganization-listbox on">
                <h4 style="font-size:32px">Update Organization</h4>
                 <button type="button" class="btn btn-create" data-toggle="modal" data-target="#pop-orglist">
                Create
                </button>
                <div class="input">
                    <p>SearchBox</p>
                    <input type="text" placeholder name>
                    <a class="Search" href="javascript:;">Search</a>
                </div>
						<form action="orgupdate.php" method="post" >
                            <div class="modal-body">
                                <div class="create-patient-name">
								<input type="hidden" name="updated_id" value="<?php echo $u_org_id;?>">
                                    <p>Company:</p>
                                    <input id="get-name" name="u_org_name" type="text" placeholder="Enter Name" value="<?php echo $u_org_name; ?>" style="margin-left:6%;width:200px;" >
                                </div>
                                
                                <div class="create-patient-age">
                                    <p>Date:</p>
                                    <input id="get-age" name="u_org_age" type="date" placeholder="Enter Date" value="<?php echo $u_org_age; ?>" style="margin-left:10%;width:200px;">
                                </div>
                                
                                <div class="create-patient-details">
                                    <p>Details:</p>
                                    <input id="get-details" name="u_org_details" type="text" placeholder="Enter Details" value="<?php echo $u_org_details ; ?>" style="margin-left:8%;width:200px;">
                                </div>
                            </div>
                           
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary" name="u_save_org">Update Now</button>
                        
							</form>
            </div>

    <script src="./js/jQuery.js"></script>
    <script src="./js/bootstrap.bundle.min.js"></script>
    <script src="./js/index.js"></script>
	
	
	
				
					
</body>
</html>


<?php
 }else{

	header("Location:../Panel/panel.php");
	
}	?>

<?php
include_once("../connection.php");
if(isset($_POST['u_save_org'])) {
 $u_org_id = $_POST['updated_id'];	
 $u_org_name = $_POST['u_org_name'];
 $u_org_age =$_POST['u_org_age'];
 $u_org_details =$_POST['u_org_details'];

$result = mysqli_query($db, "UPDATE `org` SET `org_name`='$u_org_name',`org_age`='$u_org_age',`org_desc`='$u_org_details' WHERE `org_id`='$u_org_id'");
echo "<script>alert('Record Updated successfully.')</script>";
echo "<script>window.location.href = 'dashboard.php';</script>";
echo "<script>window.location.href = 'http://localhost/Patient/Dashboard/dashboard.php';</script>";


}

?>
