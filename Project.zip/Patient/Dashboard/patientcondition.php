<?php
session_start();

if(isset($_SESSION['username'])){
  $patient_checkup_id= @$_GET["patient_condition"];
   
   ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <title>PRB Project</title>
	
	<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
</head>
<body>
    <div class="wrap">
        <div class="navigation on">
            <a class="nav-open" href="javascript:;">
                <p class="triangle"></p>
            </a>
            <p class="header">Doctor</p>
            <span class="name">Welcome,<?php echo $_SESSION['username'] ?></span>
            <div class="btnbox">
			<?php
				 include_once("../connection.php");
				$user_session = $_SESSION['username'];
				$display_role=mysqli_query($db, "SELECT * from user_session where session_username='$user_session'");
				while($displayrole_row = mysqli_fetch_array($display_role,MYSQLI_ASSOC))
				{
					$exactName=$displayrole_row["user_role"];
				
				}
				$display_roleName=mysqli_query($db, "SELECT * from user_role where role_id='$exactName'");
				while($roleName_row = mysqli_fetch_array($display_roleName,MYSQLI_ASSOC))
				{
					$loggedin_User=$roleName_row["role_name"];
				
				}
			
				
				if($loggedin_User=="Nurse")
				{
			echo"<a class='nav-btn1' href='patientlist.php'>Back To Dashboard</a>";
				}else
				{
					echo"
                <a class='nav-btn1' href='javascript:;'>Trail Organization</a>
                <a class='nav-btn2' href='javascript:;'>Create Patients</a>
                <a class='nav-btn3' href='javascript:;'>Create Studies</a>
                <a class='nav-btn4' href='javascript:;'>View Enrollment</a>";
				}?>
				<a class="nav-btn4" href="../logout.php/">Logout</a>
            </div>
            <a class="nav-btn-back" href="javascrit:;">Back to Main Page</a>
        </div>
        <div class="Mainpart">
            <div class="TrailOrganization-listbox on">
                <h4 style="height:29px;font-size:32px;margin-bottom:10px">All Patient</h4>
				You are logged as : 
				<?php
				 include_once("../connection.php");
				$user_session = $_SESSION['username'];
				$display_role=mysqli_query($db, "SELECT * from user_session where session_username='$user_session'");
				while($displayrole_row = mysqli_fetch_array($display_role,MYSQLI_ASSOC))
				{
					$exactName=$displayrole_row["user_role"];
				
				}
				$display_roleName=mysqli_query($db, "SELECT * from user_role where role_id='$exactName'");
				while($roleName_row = mysqli_fetch_array($display_roleName,MYSQLI_ASSOC))
				{
					$loggedin_User=$roleName_row["role_name"];
				
				}
				echo $loggedin_User;
				
				if($loggedin_User=="Doctor")
				{
					
					echo"<br><a href='addpatient.php' style='background:#110930;color:white;padding:5px 15px;border-radius:5px'>Add Patient</a>";
					echo" &nbsp;";
					echo"<a href='doctorappointment.php' style='background:red;color:white;padding:5px 15px;border-radius:5px'>View Patient</a>";
					echo" &nbsp;";
					echo"<a href='addnurse.php' style='background:#110930;color:white;padding:5px 15px;border-radius:5px'>Add Nurse</a>";
					echo" &nbsp;";
					echo"<a href='nurse.php' style='background:green;color:white;padding:5px 15px;border-radius:5px'>View Nurse</a>";
				
				}
				else if ($loggedin_User=="Nurse"){
					echo"<br><a href='assignbydoctor.php' style='background:green;color:white;padding:5px 15px;border-radius:5px'>Assign By Doctor</a>";
					echo" &nbsp;";
					echo"<a href='patientlist.php' style='background:red;color:white;padding:5px 15px;border-radius:5px'>View My Patients</a>";
				}
				
				else if ($loggedin_User=="Patient"){
					echo"<br><a href='bookappointments.php' style='background:green;color:white;padding:5px 15px;border-radius:5px'>Book Appointments</a>";
					echo" &nbsp;";
					
					
					echo"<a href='' style='background:orange;color:white;padding:5px 15px;border-radius:5px'>Supervision Nurse</a>";
					
				}
				?>
                 <button type="button" class="btn btn-create" data-toggle="modal" data-target="#pop-orglist">
                Create
                </button><img src="images/logo.png" width="85px" style="float:right;margin-top:-5%">
				<form action="dashboard.php" method="post" >
                <div class="input">
                    <p>SearchBox</p>
                    <input type="text" placeholder="Type Here" name="org_input">
                    <button type="submit" class="btn btn-success" name="org_search">Search</button>
                </div>
				</form>
				<center>
				<img src="images/profile.png" width="200px"><br>	
				
				<!-- Getting Patient Name-->
				<?php 
				$patientnamedetail = mysqli_query($db,"SELECT * FROM pat where pat_id='$patient_checkup_id'");

								while( $patientnamedetail1 = mysqli_fetch_array($patientnamedetail,MYSQLI_ASSOC))

								  {
									echo"<b>".$patientnamedetail2= $patientnamedetail1["pat_name"]."</b>";
								  }
				?>
				</center>
				<?php
				//Getting Loggedin User Name
				$user_session = $_SESSION['username'];
				$display_role=mysqli_query($db, "SELECT * from user_session where session_username='$user_session'");
				while($displayrole_row = mysqli_fetch_array($display_role,MYSQLI_ASSOC))
				{
				 $loggedUser=$displayrole_row["session_name"];
				
				}
				 $patient_checkup_id= @$_GET["patient_condition"];
				 $display_role22=mysqli_query($db, "SELECT * from patientcondition where added_by='$loggedUser' and pc_id='$patient_checkup_id'");
				
				while( $patientslist = mysqli_fetch_array($display_role22,MYSQLI_ASSOC))

				{
				 $pat_id= $patientslist["patient_id"];
				   $pc_id= $patientslist["pc_id"];
				  $blood_press= $patientslist["blood_pressure"];
				  $pat_temp= $patientslist["temp"];
				  $patient_tests= $patientslist["tests"];
				  $patient_oxygen= $patientslist["oxygen"];
				  $pat_heart= $patientslist["heart_rate"];
				}
		 $rowcount=mysqli_num_rows($display_role22);
				if($rowcount==1){
				?>
				<form action="patientcondition.php" method="post" style="margin-left:30%" >
						<strong><label  style="width:140px">Patient ID</label></strong>
						<input type="text" name="patient_ids" value="<?php echo $patient_checkup_id;?>" required style="padding-left:4px;border:1px solid #d1d1d1;background:#d1d1d1;border-radius:5px;width:200px;height:35px" disabled >
						<input type="hidden" name="patient_ids" value="<?php echo $patient_checkup_id;?>" required style="padding-left:4px;border:1px solid #d1d1d1;background:#d1d1d1;border-radius:5px;width:200px;height:35px" >
						<input type="hidden" name="pc_id" value="<?php echo $pc_id;?>" required style="padding-left:4px;border:1px solid #d1d1d1;background:#d1d1d1;border-radius:5px;width:200px;height:35px" >
						<br>
						<br><strong><label  style="width:140px">Blood Pressure</label></strong>
						<input type="text" name="bpressure" value="<?php echo $blood_press;	?>" required style="padding-left:4px;border:1px solid #d1d1d1;background:#d1d1d1;border-radius:5px;width:200px;height:35px" ><br>
						<br><strong><label  style="width:140px">Temperature</label></strong>
						<input type="text" name="temperature" value="<?php echo $pat_temp?>" required style="padding-left:4px;border:1px solid #d1d1d1;background:#d1d1d1;border-radius:5px;width:200px;height:35px" ><br>
						<br><strong><label  style="width:140px">Tests Conducted</label></strong>
						<select name="testsconducted" style="width:200px;height:35px" style="padding-left:4px;border:1px solid #d1d1d1;background:#d1d1d1;border-radius:5px;width:200px;height:35px">
						<option value="<?php echo $patient_tests;?>"><?php echo $patient_tests;?></option>
						<option value="Yes">Yes</option>
						<option value="No">No</option>
						</select><br>
						<br><strong><label  style="width:140px">Oxygen Level</label></strong>
						<select name="oxygenlevel" style="width:200px;height:35px" style="padding-left:4px;border:1px solid #d1d1d1;background:#d1d1d1;border-radius:5px;width:200px;height:35px">
						<option value="<?php echo $patient_oxygen;?>"><?php echo $patient_oxygen;?></option>
						<option value="Normal">Normal</option>
						<option value="Low">Low</option>
						<option value="High">High</option>
						</select><br>
						<br><strong><label  style="width:140px">Heart Rate</label></strong>
						<input type="text" name="hrate" value="<?php echo $pat_heart;?>" required style="padding-left:4px;border:1px solid #d1d1d1;background:#d1d1d1;border-radius:5px;width:200px;height:35px" ><br>
						
						<br><br>	<strong><label  style="width:140px"></label></strong>
						<button type="submit" class="btn btn-primary" name="patientcondition_update">Update Record</button>
						
				
				</form>
				
				<?php } else { ?>
				
				<form action="patientcondition.php" method="post" style="margin-left:30%" >
						<strong><label  style="width:140px">Patient ID</label></strong>
						<input type="text" name="patient_ids" value="<?php echo $patient_checkup_id;?>" required style="padding-left:4px;border:1px solid #d1d1d1;background:#d1d1d1;border-radius:5px;width:200px;height:35px" disabled ><br>
						<input type="hidden" name="patient_ids" value="<?php echo $patient_checkup_id;?>" required style="padding-left:4px;border:1px solid #d1d1d1;background:#d1d1d1;border-radius:5px;width:200px;height:35px" >
						<br><strong><label  style="width:140px">Blood Pressure</label></strong>
						<input type="text" name="bpressure"  required style="padding-left:4px;border:1px solid #d1d1d1;background:#d1d1d1;border-radius:5px;width:200px;height:35px" ><br>
						<br><strong><label  style="width:140px">Temperature</label></strong>
						<input type="text" name="temperature"  required style="padding-left:4px;border:1px solid #d1d1d1;background:#d1d1d1;border-radius:5px;width:200px;height:35px" ><br>
						<br><strong><label  style="width:140px">Tests Conducted</label></strong>
						<select name="testsconducted" style="width:200px;height:35px" style="padding-left:4px;border:1px solid #d1d1d1;background:#d1d1d1;border-radius:5px;width:200px;height:35px">
						<option value="Yes">Yes</option>
						<option value="No">No</option>
						</select><br>
						<br><strong><label  style="width:140px">Oxygen Level</label></strong>
						<select name="oxygenlevel" style="width:200px;height:35px" style="padding-left:4px;border:1px solid #d1d1d1;background:#d1d1d1;border-radius:5px;width:200px;height:35px">
						<option value="Normal">Normal</option>
						<option value="Low">Low</option>
						<option value="High">High</option>
						</select><br>
						<br><strong><label  style="width:140px">Heart Rate</label></strong>
						<input type="text" name="hrate"  required style="padding-left:4px;border:1px solid #d1d1d1;background:#d1d1d1;border-radius:5px;width:200px;height:35px" ><br>
						
						<br><br>	<strong><label  style="width:140px"></label></strong>
						<button type="submit" class="btn btn-primary" name="patientcondition_save">Submit</button>
						
				
				</form>
				
<?php } ?>
				
            </div>
            <div class="Patient-listbox">
                <h4>Patient List</h4>
                <!-- <a class="btn-create" href="javascript:;">Create</a> -->
                <!-- Button trigger modal -->
                <button type="button" class="btn btn-create" data-toggle="modal" data-target="#pop-patientlist">
                Create
                </button>
                <!-- Modal -->
                <div class="modal fade" id="pop-patientlist" tabindex="-1" aria-labelledby="pop-patientlistlabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Create Patientlist</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            </div>
							<form action="dashboard.php" method="post" >
                            <div class="modal-body">
								
                                <div class="create-patient-name">
                                    <p>Name:</p>
                                    <input id="get-name" type="text"  name="pat_name" placeholder="name" required>
                                </div>
                                <div class="create-patient-gender">
                                    <p>Gender:</p>
                                    <select name="pat_gender" id="get-gender">
                                        <option value="Male">Male</option>
                                        <option value="Female">Female</option>
                                    </select>
                                </div>
                                <div class="create-patient-age">
                                    <p>Age:</p>
                                    <input id="get-age" type="text" name="pat_age" placeholder="Age" required>
                                </div>
                                <div class="create-patient-address">
                                    <p>Address:</p>
                                    <input id="get-address" type="text" name="pat_address" placeholder="Address" required>
                                </div>
                                <div class="create-patient-details">
                                    <p>Details:</p>
                                    <input id="get-details" type="text" name="pat_details" placeholder="Details" required>
                                </div>
                            </div>
                            <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary" name="pat_save">Save changes</button>
                            </div>
							</form>
                        </div>
                    </div>
                </div>
                <form action="dashboard.php" method="post" >
                <div class="input">
                    <p>SearchBox</p>
                    <input type="text" placeholder="Type Here" name="pat_input">
                    <button type="submit" class="btn btn-success" name="pat_search">Search</button>
                </div>
				</form>
                <table>
							  <tr>
							  <th>Serial No.</th>
								<th>Name</th>
								<th>Gender</th>
								<th>Age</th>
								<th>Address</th>
								<th>Detail</th>
								<th>Action</th>
							  </tr>
							  <?php
							  include_once("../connection.php");
							  $i=0;
							  $user_selectpat = $_SESSION['username'];
							  $result = mysqli_query($db,"SELECT * FROM pat where added_by='$user_selectpat'");

								while( $patshow_row = mysqli_fetch_array($result,MYSQLI_ASSOC))

								  {
									  $i++;
							  
							  ?>
							  <tr>
								<td><?php echo $i;?></td>
								<td><?php echo $patshow_row['pat_name'];?></td>
								<td><?php echo $patshow_row['pat_gender'];?></td>
								<td><?php echo $patshow_row['pat_age'];?></td>
								<td><?php echo $patshow_row['pat_address'];?></td>
								<td><?php echo $patshow_row['pat_desc'];?></td>
								<td>
								<a href="patientupdate.php?pat_edit=<?php echo $patshow_row['pat_id'];?>" >Edit</a> &nbsp;&nbsp;
								<a href="?pat_delete=<?php echo $patshow_row['pat_id'];?>">Delete</a>
								</td>
							  </tr>
							<?php } ?>
							</table>
               
            </div>
            <div class="Study-listbox">
                <h4>Study</h4>
                <button type="button" class="btn btn-create" data-toggle="modal" data-target="#pop-stulist">
                Create
                </button>
                <form action="dashboard.php" method="post" >
                <div class="input">
                    <p>SearchBox</p>
                    <input type="text" placeholder="Type Here" name="stu_input">
                    <button type="submit" class="btn btn-success" name="stu_search">Search</button>
                </div>
                  </form>
             
                  <table>
							  <tr>
							  <th>Serial No.</th>
								<th>Student Name</th>
								<th>Number of Member</th>
								<th>Date</th>
								<th>Class</th>
								<th>Course Status</th>
								<th>Action</th>
							  </tr>
							  <?php
							  include_once("../connection.php");
							  $i=0;
							  $user_selectstu = $_SESSION['username'];
							  $result = mysqli_query($db,"SELECT * FROM stu where added_by='$user_selectstu'");

								while( $stushow_row = mysqli_fetch_array($result,MYSQLI_ASSOC))

								  {
									  $i++;
							  
							  ?>
							  <tr>
								<td><?php echo $i;?></td>
								<td><?php echo $stushow_row['stu_name'];?></td>
								<td><?php echo $stushow_row['stu_no_member'];?></td>
								<td><?php echo $stushow_row['stu_date'];?></td>
								<td><?php echo $stushow_row['stu_class'];?></td>
								<td><?php echo $stushow_row['stu_status'];?></td>
								<td>
								<a href="stuupdate.php?stu_edit=<?php echo $stushow_row['stu_id'];?>" >Edit</a> &nbsp;&nbsp;
								<a href="?stu_delete=<?php echo $stushow_row['stu_id'];?>">Delete</a>
								</td>
							  </tr>
<?php } ?>
							</table>
             
               
            </div>
            <div class="ViewEnrollment-listbox">
                <h4>Enrollment</h4>
                 <button type="button" class="btn btn-create" data-toggle="modal" data-target="#pop-enrlist">
                Create
                </button>
                <form action="dashboard.php" method="post" >
                <div class="input">
                    <p>SearchBox</p>
                    <input type="text" placeholder="Type Here" name="enr_input">
                    <button type="submit" class="btn btn-success" name="enr_search">Search</button>
                </div>
				</form>
               
                     <table>
							  <tr>
							  <th>Serial No.</th>
								<th>Student Name</th>
								<th>Number of Member</th>
								<th>Date</th>
								<th>Class</th>
								<th>Course Status</th>
								<th>Action</th>
							  </tr>
							  <?php
							  include_once("../connection.php");
							  $i=0;
							    $user_selectenr = $_SESSION['username'];
							  $result = mysqli_query($db,"SELECT * FROM enr where added_by='$user_selectenr'");

								while( $enrshow_row = mysqli_fetch_array($result,MYSQLI_ASSOC))

								  {
									  $i++;
							  
							  ?>
							  <tr>
								<td><?php echo $i;?></td>
								<td><?php echo $enrshow_row['enr_name'];?></td>
								<td><?php echo $enrshow_row['enr_no_member'];?></td>
								<td><?php echo $enrshow_row['enr_date'];?></td>
								<td><?php echo $enrshow_row['enr_class'];?></td>
								<td><?php echo $enrshow_row['enr_status'];?></td>
								<td>
								<a href="enrupdate.php?enr_edit=<?php echo $enrshow_row['enr_id'];?>" >Edit</a> &nbsp;&nbsp;
								<a href="?enr_delete=<?php echo $enrshow_row['enr_id'];?>">Delete</a>
								</td>
							  </tr>
<?php } ?>
							</table>
            
            </div>
        </div>
    </div>
    <script src="./js/jQuery.js"></script>
    <script src="./js/bootstrap.bundle.min.js"></script>
    <script src="./js/index.js"></script>
	
	
	
	<!-- Modal -->
                <div class="modal fade" id="pop-orglist" tabindex="-1" aria-labelledby="pop-orglistlabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Create Organization</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            </div>
							<form action="dashboard.php" method="post" >
                            <div class="modal-body">
                                <div class="create-patient-name">
                                    <p>Name:</p>
                                    <input id="get-name" name="org_name" type="text" placeholder="Enter Name"  >
                                </div>
                                <div class="create-patient-gender">
                                    <p>Gender:</p>
                                    <select name="org_gender" id="get-gender">
                                        <option value="Male">Male</option>
                                        <option value="Female">Female</option>
                                    </select>
                                </div>
                                <div class="create-patient-age">
                                    <p>Age:</p>
                                    <input id="get-age" name="org_age" type="text" placeholder="Enter Age" >
                                </div>
                                <div class="create-patient-address">
                                    <p>Address:</p>
                                    <input id="get-address" name="org_address" type="text" placeholder="Enter Address">
                                </div>
                                <div class="create-patient-details">
                                    <p>Details:</p>
                                    <input id="get-details" name="org_details" type="text" placeholder="Enter Details" >
                                </div>
                            </div>
                            <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary" name="save_org">Save changes</button>
                            </div>
							</form>
                        </div>
                    </div>
                </div>
				
				
				
				
				<!-- Study Modal -->
                <div class="modal fade" id="pop-stulist" tabindex="-1" aria-labelledby="pop-stulistlabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Create Study</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            </div>
							<form action="dashboard.php" method="post" >
                            <div class="modal-body">
                                <div class="create-patient-name">
                                    <p>Name:</p>
                                    <input id="get-name" name="stu_name" type="text" placeholder="Enter Name"  >
                                </div>
                                
                                <div class="create-patient-age">
                                    <p>No of Members:</p>
                                    <input id="get-age" name="stu_no_member" type="text" placeholder="Enter Number of Members" >
                                </div>
                                <div class="create-patient-address">
                                    <p>Date:</p>
                                    <input id="get-address" name="stu_date" type="date" placeholder="Enter Date">
                                </div>
                                <div class="create-patient-details">
                                    <p>Class:</p>
                                    <input id="get-details" name="stu_class" type="text" placeholder="Enter Details" >
                                </div>
								<div class="create-patient-gender">
                                    <p>Coures Status:</p>
                                    <select name="stu_status" id="get-gender">
                                        <option value="Complete">Complete</option>
                                        <option value="InComplete">InComplete</option>
                                    </select>
                                </div>
                            </div>
                            <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary" name="save_stu">Save changes</button>
                            </div>
							</form>
                        </div>
                    </div>
                </div>
				
				
				<!-- Enrollment Modal -->
                <div class="modal fade" id="pop-enrlist" tabindex="-1" aria-labelledby="pop-enrlistlabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Create Enrollment</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            </div>
							<form action="dashboard.php" method="post" >
                            <div class="modal-body">
                                <div class="create-patient-name">
                                    <p>Name:</p>
                                    <input id="get-name" name="enr_name" type="text" placeholder="Enter Name"  >
                                </div>
                                
                                <div class="create-patient-age">
                                    <p>No of Members:</p>
                                    <input id="get-age" name="enr_no_member" type="text" placeholder="Enter Number of Members" >
                                </div>
                                <div class="create-patient-address">
                                    <p>Date:</p>
                                    <input id="get-address" name="enr_date" type="date" placeholder="Enter Date">
                                </div>
                                <div class="create-patient-details">
                                    <p>Class:</p>
                                    <input id="get-details" name="enr_class" type="text" placeholder="Enter Details" >
                                </div>
								<div class="create-patient-gender">
                                    <p>Coures Status:</p>
                                    <select name="enr_status" id="get-gender">
                                        <option value="Complete">Complete</option>
                                        <option value="InComplete">InComplete</option>
                                    </select>
                                </div>
                            </div>
                            <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary" name="save_enr">Save changes</button>
                            </div>
							</form>
                        </div>
                    </div>
                </div>
				
				
					
</body>
</html>


<?php
 }else{

	header("Location:../Panel/panel.php");
	
}	?>


<?php
$user_session = $_SESSION['username'];
include_once("../connection.php");
if(isset($_POST['save_org'])) {	
$org_name = $_POST['org_name'];
$org_gender = $_POST['org_gender'];
$org_age = $_POST['org_age'];

$org_address =$_POST['org_address'];
$org_details =$_POST['org_details'];

$result = mysqli_query($db, "INSERT INTO `org`(`org_name`, `org_gender`, `org_age`, `org_address`, `org_desc`, `added_by`) VALUES ('$org_name','$org_gender','$org_age','$org_address','$org_details','$user_session')");
echo "<script>alert('Data added successfully.')</script>";
echo "<script>window.location.href = 'dashboard.php';</script>";
}

if(isset($_GET['org_delete'])){
	$org_del=$_GET['org_delete'];
	$result = mysqli_query($db, "DELETE FROM `org` WHERE org_id ='$org_del' and added_by='$user_session'");
	echo"<script>alert('Organization Member Deleted Successfully')</script>";
	echo "<script>window.location.href = 'dashboard.php';</script>";
}



if(isset($_POST['pat_save'])) {	
$pat_name = $_POST['pat_name'];
$pat_gender = $_POST['pat_gender'];
$pat_age = $_POST['pat_age'];

$pat_address =$_POST['pat_address'];
$pat_details =$_POST['pat_details'];

$result = mysqli_query($db, "INSERT INTO `pat`(`pat_name`, `pat_gender`, `pat_age`, `pat_address`, `pat_desc`, `added_by`) VALUES ('$pat_name','$pat_gender','$pat_age','$pat_address','$pat_details','$user_session')");
echo "<script>alert('Data added successfully.')</script>";
echo "<script>window.location.href = 'dashboard.php';</script>";
}

if(isset($_GET['pat_delete'])){
	$pat_del=$_GET['pat_delete'];
	$result = mysqli_query($db, "DELETE FROM `pat` WHERE pat_id ='$pat_del' and added_by='$user_session'");
	echo"<script>alert('Patient Member Deleted Successfully')</script>";
	echo "<script>window.location.href = 'dashboard.php';</script>";
}


if(isset($_POST['save_stu'])) {	
$stu_name = $_POST['stu_name'];
$stu_no_member = $_POST['stu_no_member'];
$stu_date = $_POST['stu_date'];

$stu_class =$_POST['stu_class'];
$stu_status =$_POST['stu_status'];

$result = mysqli_query($db, "INSERT INTO `stu`(`stu_name`, `stu_no_member`, `stu_date`, `stu_class`, `stu_status`, `added_by`) VALUES ('$stu_name','$stu_no_member','$stu_date','$stu_class','$stu_status','$user_session')");
echo "<script>alert('Data added successfully.')</script>";
echo "<script>window.location.href = 'dashboard.php';</script>";
}

if(isset($_GET['stu_delete'])){
	$stu_delete=$_GET['stu_delete'];
	$result = mysqli_query($db, "DELETE FROM `stu` WHERE stu_id ='$stu_delete'");
	echo"<script>alert('Study Record Deleted Successfully')</script>";
	echo "<script>window.location.href = 'dashboard.php';</script>";
}


if(isset($_POST['save_enr'])) {	
$enr_name = $_POST['enr_name'];
$enr_no_member = $_POST['enr_no_member'];
$enr_date = $_POST['enr_date'];

$enr_class =$_POST['enr_class'];
$enr_status =$_POST['enr_status'];

$result = mysqli_query($db, "INSERT INTO `enr`(`enr_name`, `enr_no_member`, `enr_date`, `enr_class`, `enr_status`, `added_by`) VALUES ('$enr_name','$enr_no_member','$enr_date','$enr_class','$enr_status','$user_session')");
echo "<script>alert('Data added successfully.')</script>";
echo "<script>window.location.href = 'dashboard.php';</script>";
}

if(isset($_GET['enr_delete'])){
	$stu_delete=$_GET['enr_delete'];
	$result = mysqli_query($db, "DELETE FROM `enr` WHERE enr_id ='$enr_delete' and added_by='$user_session'");
	echo"<script>alert('Study Record Deleted Successfully')</script>";
	echo "<script>window.location.href = 'dashboard.php';</script>";
}
if(isset($_POST['org_search'])){
	$org_input_search= $_POST['org_input'];
	echo "<script>window.location.href = 'search.php?org_input=$org_input_search';</script>";
}
if(isset($_POST['pat_search'])){
	$pat_input_search= $_POST['pat_input'];
	echo "<script>window.location.href = 'pat_search.php?pat_input=$pat_input_search';</script>";
}
if(isset($_POST['stu_search'])){
	$stu_input_search= $_POST['stu_input'];
	echo "<script>window.location.href = 'stu_search.php?stu_input=$stu_input_search';</script>";
}
if(isset($_POST['enr_search'])){
	$enr_input_search= $_POST['enr_input'];
	echo "<script>window.location.href = 'enr_search.php?enr_input=$enr_input_search';</script>";
}

//Checking Nurse is assigned to doctor or not before confirming patient appointment

if(isset($_POST['patientcondition_save'])){
		$user_session = $_SESSION['username'];
		$display_role121=mysqli_query($db, "SELECT * from user_session where session_username='$user_session'");
				while($displayrole212_row = mysqli_fetch_array($display_role121,MYSQLI_ASSOC))
				{
					$exactName211=$displayrole212_row["session_name"];
				
				}
		
		$patient_id = $_POST['patient_ids'];
		$bpressure = $_POST['bpressure'];
		$temperature = $_POST['temperature'];
		$testsconducted = $_POST['testsconducted'];
		$oxygenlevel = $_POST['oxygenlevel'];
		$hrate = $_POST['hrate'];
		
		$pat_condition = mysqli_query($db,"INSERT INTO `patientcondition`(`patient_id`, `blood_pressure`, `temp`, `tests`, `oxygen`, `heart_rate`, `added_by`)
		VALUES ('$patient_id','$bpressure','$temperature','$testsconducted','$oxygenlevel','$hrate','$exactName211')");
			echo"<script>alert('Patient Condtion Status Added Successfully')</script>";
			echo "<script>window.location.href = 'patientlist.php';</script>";
		

}
if(isset($_POST['patientcondition_update'])){
		$user_session = $_SESSION['username'];
		$display_role121=mysqli_query($db, "SELECT * from user_session where session_username='$user_session'");
				while($displayrole212_row = mysqli_fetch_array($display_role121,MYSQLI_ASSOC))
				{
					$exactName2112=$displayrole212_row["session_name"];
				
				}
		
		
		$pc_id = $_POST['pc_id'];
		$bpressure = $_POST['bpressure'];
		$temperature = $_POST['temperature'];
		$testsconducted = $_POST['testsconducted'];
		$oxygenlevel = $_POST['oxygenlevel'];
		$hrate = $_POST['hrate'];
		
		$pat_condition = mysqli_query($db,"UPDATE `patientcondition` SET `blood_pressure`='$bpressure',`temp`='$temperature',`tests`='$testsconducted',`oxygen`='$oxygenlevel',`heart_rate`='$hrate ',`added_by`='$exactName2112' WHERE pc_id='$pc_id'");
			if($pat_condition){
			echo"<script>alert('Patient Record Updated Successfully')</script>";
			echo "<script>window.location.href = 'patientconditionlist.php';</script>";
			}
		

}
?>