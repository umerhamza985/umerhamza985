<?php
session_start();
include_once("../connection.php");
 @$u_pat_id = $_GET['pat_edit'];
if(isset($_SESSION['username'])){

 if($u_pat_id){
 $sql = "SELECT * FROM `pat` WHERE pat_id='$u_pat_id'";
      $result = mysqli_query($db,$sql);
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
			$u_pat_name = $row['pat_name'];
			$u_pat_gender = $row['pat_gender'];
			$u_pat_age = $row['pat_age'];
			$u_pat_address = $row['pat_address'];
			$u_pat_details = $row['pat_desc'];
 }

   
   ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <title>PRB Project</title>
	
	<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
</head>
<body>
    <div class="wrap">
        <div class="navigation on">
            <a class="nav-open" href="javascript:;">
                <p class="triangle"></p>
            </a>
            <p class="header">Staff Interface</p>
            <span class="name">Welcome,<?php echo $_SESSION['username'] ?></span>
            <div class="btnbox">
                <a class="nav-btn1" href="dashboard.php">Trail Organization</a>
                <a class="nav-btn2" href="dashboard.php">Create Patients</a>
                <a class="nav-btn3" href="dashboard.php">Create Studies</a>
                <a class="nav-btn4" href="dashboard.php">View Enrollment</a>
				<a class="nav-btn4" href="../logout.php/">Logout</a>
            </div>
            <a class="nav-btn-back" href="javascrit:;">Back to Main Page</a>
        </div>
        <div class="Mainpart">
            <div class="TrailOrganization-listbox on">
                <h4 style="font-size:32px">Update Patient</h4>
                 <button type="button" class="btn btn-create" data-toggle="modal" data-target="#pop-orglist">
                Create
                </button>
                <div class="input">
                    <p>SearchBox</p>
                    <input type="text" placeholder name>
                    <a class="Search" href="javascript:;">Search</a>
                </div>
						<form action="patientupdate.php" method="post" >
                            <div class="modal-body">
                                <div class="create-patient-name">
								<input type="hidden" name="updated_id" value="<?php echo $u_pat_id;?>">
                                    <p>Name:</p>
                                    <input id="get-name" name="u_pat_name" type="text" placeholder="Enter Name" value="<?php echo $u_pat_name; ?>" >
                                </div>
                                <div class="create-patient-gender">
                                    <p>Gender:</p>
                                    <select name="u_pat_gender" id="get-gender">
										<option value="<?php echo $u_pat_gender; ?>"><?php echo $u_pat_gender; ?></option>
                                        <option value="Male">Male</option>
                                        <option value="Female">Female</option>
                                    </select>
                                </div>
                                <div class="create-patient-age">
                                    <p>Age:</p>
                                    <input id="get-age" name="u_pat_age" type="text" placeholder="Enter Age" value="<?php echo $u_pat_age; ?>">
                                </div>
                                <div class="create-patient-address">
                                    <p>Address:</p>
                                    <input id="get-address" name="u_pat_address" type="text" placeholder="Enter Address" value="<?php echo $u_pat_address; ?>">
                                </div>
                                <div class="create-patient-details">
                                    <p>Details:</p>
                                    <input id="get-details" name="u_pat_details" type="text" placeholder="Enter Details" value="<?php echo $u_pat_details ; ?>" >
                                </div>
                            </div>
                           
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary" name="u_save_pat">Update Now</button>
                        
							</form>
            </div>

    <script src="./js/jQuery.js"></script>
    <script src="./js/bootstrap.bundle.min.js"></script>
    <script src="./js/index.js"></script>
	
	
	
				
					
</body>
</html>


<?php
 }else{

	header("Location:../Panel/panel.php");
	
}	?>

<?php
include_once("../connection.php");
if(isset($_POST['u_save_pat'])) {
 $u_pat_id = $_POST['updated_id'];	
 $u_pat_name = $_POST['u_pat_name'];
 $u_pat_gender = $_POST['u_pat_gender'];
 $u_pat_age =$_POST['u_pat_age'];
 $u_pat_address = $_POST['u_pat_address'];
 $u_pat_details =$_POST['u_pat_details'];

$result = mysqli_query($db, "UPDATE `pat` SET `pat_name`='$u_pat_name',`pat_gender`='$u_pat_gender',`pat_age`='$u_pat_age',`pat_address`='$u_pat_address',`pat_desc`='$u_pat_details' WHERE `pat_id`='$u_pat_id'");
echo "<script>alert('Record Updated successfully.')</script>";
echo "<script>window.location.href = 'dashboard.php';</script>";


}

?>
