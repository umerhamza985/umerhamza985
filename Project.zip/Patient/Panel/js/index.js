$('.btn-signup').on('click',function(){
  $('.center.login').css('display','none')
  $('.center.signup').css('display','block')
})
 function locationreload() {
                location.reload();
                 
        }