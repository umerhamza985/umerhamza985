<?php

   session_start();
   if(isset($_SESSION['username'])){
header("location: ../Dashboard/dashboard.php");
   }else{
  
?>
<!DOCTYPE html>
<html lang="en" dir = "1tr">
    <head>
        <meta charset="utf-8">
        <title>Animated Login Form</title>
        <link rel="stylesheet" href="style.css">
    
    </head>
    <body>
        <div class="wrap">
            <div class="center login">
            <h1>Login</h1>
            <form method="post" action="panel.php" autocomplete="off">
                <div class="txt_field">
                    <input type="text" name="username" required autocomplete="off">
                    <span></span>
                    <label>Username</label>
                </div>
                <div class="txt_field">
                    <input type="password" name="password" required autocomplete="off">
                    <span></span>
                    <label>Password</label>
                </div>
                <div class="pass">Forgot Password?
                </div>
                <input type="submit" value="Login" name="login">
                <div class="signup_link">
                </div>
				<Br><br>
            </form>
            <a class="btn-signup" style="float:right" href="javascript:;">Sign up</a>
            <img class="outlook" src="./outlook.png" alt>
            </div>
			
            <div class="center signup">
                <h1>Sign up</h1>
                <form action="panel.php" method="post" name="form2">
				 <div class="txt_field">
                        <input type="text" name="name" required autocomplete="off">
                        <span></span>
                        <label id="get-name">Name</label>
                    </div>
                    <div class="txt_field">
                        <input type="text" name="username" required autocomplete="off">
                        <span></span>
                        <label id="get-username">Username</label>
                    </div>
                    <div class="txt_field">
                        <input type="password" name="password" required autocomplete="off">
                        <span></span>
                        <label id="get-password">Password</label>
                    </div>
					 <div class="txt_field">
                    <select name="role">
					<option value="Doctor">Staff</option>
					<option value="Nurse">Nurse</option>
					</select>
                </div>
                    <div class="pass">Forgot Password?
                    </div>
                    <input type="submit" name="register" value="Submit">
                    <div class="signup_link">
                    </div>
					<Br><br>
                </form>
				  <a class="btn-signup" onclick = "locationreload()" style="float:right" href="javascript:;">Sign In</a>
                <img class="outlook" src="./outlook.png" alt>
                </div>
        </div>
        <script src="./js/jQuery.js"></script>
        <script src="./js/index.js"></script>
    </body>
</html>
   <?php } ?>
 <?php 
  
include_once("../connection.php");

if(isset($_POST['register'])) {	
$name = $_POST['name'];
$email = $_POST['username'];
$password =$_POST['password'];
$role =$_POST['role'];
if($role !=""){
	$check_role=mysqli_query($db, "SELECT * from user_role where role_name='$role'");
	 $role_row = mysqli_fetch_array($check_role,MYSQLI_ASSOC);
     //echo $row['session_password'];
      $role_count = mysqli_num_rows($check_role);
	  if($role_count == 1) {
		  $role_id=$role_row["role_id"];
	  }
}

$result = mysqli_query($db, "INSERT INTO `user_session`(`user_role`,`session_name`, `session_username`, `session_password`) VALUES ('$role_id','$name','$email','$password')");
echo "<script>alert('Congratulations! You are registed successfully.')</script>";
echo "<script>window.location.href = '/Patient/Panel/panel.php';</script>";
}



if(isset($_POST['login'])) {

   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
      // username and password sent from form 
      
      $myusername = mysqli_real_escape_string($db,$_POST['username']);
      $mypassword = mysqli_real_escape_string($db,$_POST['password']); 
      //echo "<script>alert('$myusername'+'$mypassword')</script>";
	
      $sql = "SELECT * FROM `user_session` WHERE session_username='$myusername' and session_password='$mypassword'";
      $result = mysqli_query($db,$sql);
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
     //echo $row['session_password'];
      $count = mysqli_num_rows($result);
	 // echo $count;
      // If result matched $myusername and $mypassword, table row must be 1 row
		
      if($count == 1) {
         //session_register("myusername");
		 $_SESSION['username'] = $myusername;
		 echo $_SESSIOn['username'];
         echo "<script>alert('You have login Successfully')</script>";
         header("location: ../Dashboard/dashboard.php");
      }else {
         $error = "Your Login Name or Password is invalid";
      }
   }
}
 
?>  
