<?php
$databaseHost = 'localhost';
$databaseName = 'patient';
$databaseUsername = 'root';
$databasePassword = '';

$db = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName); 
?>