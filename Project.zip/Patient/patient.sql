-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 10, 2022 at 06:15 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 7.4.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `patient`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `app_id` int(100) NOT NULL,
  `patient_name` varchar(100) NOT NULL,
  `app_dr` varchar(100) NOT NULL,
  `app_availbleday` varchar(100) NOT NULL,
  `app_date` date NOT NULL,
  `app_nurse` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`app_id`, `patient_name`, `app_dr`, `app_availbleday`, `app_date`, `app_nurse`) VALUES
(13, 'Javad', 'Ali Asad', 'Friday', '2022-10-08', 'Fatima Ahmad');

-- --------------------------------------------------------

--
-- Table structure for table `enr`
--

CREATE TABLE `enr` (
  `enr_id` int(100) NOT NULL,
  `enr_name` varchar(100) NOT NULL,
  `enr_no_member` varchar(100) NOT NULL,
  `enr_date` varchar(100) NOT NULL,
  `enr_class` varchar(100) NOT NULL,
  `enr_status` varchar(100) NOT NULL,
  `added_by` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `enr`
--

INSERT INTO `enr` (`enr_id`, `enr_name`, `enr_no_member`, `enr_date`, `enr_class`, `enr_status`, `added_by`) VALUES
(1, 'Dilshad Ahmad', '23/36', '2022-09-01', 'Super Classes', 'Complete   ', 'aqib668'),
(2, 'Zaleez Ahmad', '23/35', '2022-08-31', 'Super Class', 'InComplete', 'waseem123'),
(3, 'Zaleez Ahmad', '23/35', '2022-09-01', 'Super Class', 'Complete', 'imran668'),
(4, 'Disshad', '23/35', '2022-10-08', 'Super Class', 'Complete', 'aliasad123');

-- --------------------------------------------------------

--
-- Table structure for table `nurse`
--

CREATE TABLE `nurse` (
  `nurse_id` int(100) NOT NULL,
  `doctor_id` int(100) NOT NULL,
  `nurse_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `nurse`
--

INSERT INTO `nurse` (`nurse_id`, `doctor_id`, `nurse_name`) VALUES
(16, 3, 'Saba Faisal'),
(19, 11, 'Saba Faisal'),
(20, 13, 'Fatima Noor'),
(21, 13, 'Fatima Ahmad'),
(23, 3, 'Noor'),
(24, 4, 'Noor'),
(25, 4, 'Maham'),
(26, 3, 'Maham');

-- --------------------------------------------------------

--
-- Table structure for table `org`
--

CREATE TABLE `org` (
  `org_id` int(100) NOT NULL,
  `org_name` varchar(100) NOT NULL,
  `org_age` varchar(100) NOT NULL,
  `org_desc` varchar(100) NOT NULL,
  `added_by` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `org`
--

INSERT INTO `org` (`org_id`, `org_name`, `org_age`, `org_desc`, `added_by`) VALUES
(1, 'Waseem Khan', '2022-10-10', 'QA', 'aqib668'),
(2, 'Noman Ijaz', '2022-10-10', 'Actor', 'waseem123'),
(5, 'Saeed Gul', '2022-10-11', 'Developer Employees', 'aqib668'),
(6, 'Imran Khan', '2022-10-10', 'Politians', 'waseem123'),
(9, 'Wajahid', '2022-10-10', 'Engineer', 'imran668'),
(12, 'Net Tech', '2022-10-10', 'QAs', 'aqib668');

-- --------------------------------------------------------

--
-- Table structure for table `pat`
--

CREATE TABLE `pat` (
  `pat_id` int(100) NOT NULL,
  `pat_name` varchar(100) NOT NULL,
  `pat_gender` varchar(100) NOT NULL,
  `pat_age` varchar(100) NOT NULL,
  `pat_address` varchar(100) NOT NULL,
  `pat_desc` varchar(100) NOT NULL,
  `showto` varchar(100) NOT NULL,
  `added_by` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pat`
--

INSERT INTO `pat` (`pat_id`, `pat_name`, `pat_gender`, `pat_age`, `pat_address`, `pat_desc`, `showto`, `added_by`) VALUES
(2, 'Fiaz Hussain', 'Male', '23', 'United Kingdom', 'Students', 'Maham', 'aqib668'),
(3, 'Saam Malik', 'Male', '21', 'UK', 'Student', 'Maham', 'waseem123'),
(5, 'Saraz Khan', 'Female', '21', 'UK', 'Student', '', 'imran668'),
(6, 'Javaid', 'Male', '12', 'Lahore', 'Demo', '', 'aliasad123');

-- --------------------------------------------------------

--
-- Table structure for table `patientcondition`
--

CREATE TABLE `patientcondition` (
  `pc_id` int(100) NOT NULL,
  `patient_id` int(100) NOT NULL,
  `blood_pressure` varchar(100) NOT NULL,
  `temp` varchar(100) NOT NULL,
  `tests` varchar(100) NOT NULL,
  `oxygen` varchar(100) NOT NULL,
  `heart_rate` varchar(100) NOT NULL,
  `added_by` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `patientcondition`
--

INSERT INTO `patientcondition` (`pc_id`, `patient_id`, `blood_pressure`, `temp`, `tests`, `oxygen`, `heart_rate`, `added_by`) VALUES
(8, 10, 'Normal to Lows', '125C', 'Yes', 'Normal', '123 ', 'Saba Faisal'),
(9, 9, 'Normal to Low', '1250', 'Yes', 'Normal', '123 ', 'Saba Faisal'),
(10, 12, 'Normal to Low', '125C', 'Yes', 'Normal', '123', 'Fatima Ahmad'),
(11, 2, 'Normal to Low', '125C', 'No', 'Low', '12345  ', 'Noor'),
(12, 3, 'Normal to Low', '125C', 'Yes', 'Normal', '123', 'Noor'),
(13, 3, 'Normal to Low', '125C', 'Yes', 'Normal', '123 ', 'Maham'),
(14, 2, 'Test1', '1250C', 'No', 'Low', '123', 'Maham');

-- --------------------------------------------------------

--
-- Table structure for table `stu`
--

CREATE TABLE `stu` (
  `stu_id` int(100) NOT NULL,
  `stu_name` varchar(100) NOT NULL,
  `stu_no_member` varchar(100) NOT NULL,
  `stu_date` date NOT NULL,
  `stu_class` varchar(100) NOT NULL,
  `stu_status` varchar(100) NOT NULL,
  `added_by` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `stu`
--

INSERT INTO `stu` (`stu_id`, `stu_name`, `stu_no_member`, `stu_date`, `stu_class`, `stu_status`, `added_by`) VALUES
(2, 'Cancer Study', '11/24', '2022-09-01', '21/36', 'Complete     ', 'aqib668'),
(4, 'Khalid Hussain', '11/20', '2022-09-01', 'Demo', 'InComplete', 'imran668');

-- --------------------------------------------------------

--
-- Table structure for table `user_role`
--

CREATE TABLE `user_role` (
  `role_id` int(100) NOT NULL,
  `role_name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_role`
--

INSERT INTO `user_role` (`role_id`, `role_name`) VALUES
(1, 'Doctor'),
(2, 'Nurse');

-- --------------------------------------------------------

--
-- Table structure for table `user_session`
--

CREATE TABLE `user_session` (
  `session_id` int(11) NOT NULL,
  `user_role` varchar(100) NOT NULL,
  `session_name` varchar(100) NOT NULL,
  `session_username` varchar(100) NOT NULL,
  `session_password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_session`
--

INSERT INTO `user_session` (`session_id`, `user_role`, `session_name`, `session_username`, `session_password`) VALUES
(3, '1', 'Aqib', 'aqib668', '12345'),
(4, '1', 'Waseem', 'waseem123', '12345'),
(5, '2', 'Saba Faisal', 'saba123', '12345'),
(6, '1', 'Saad Ahmad', 'saad123', '12345'),
(7, '1', 'Jameel Farooq', 'jameel121', '12345'),
(8, '2', 'Noor', 'noor123', '12345'),
(9, '2', 'Fatima Noor', 'fatima123', '12345'),
(11, '1', 'Fiaz Hussain', 'fiaz123', '12345'),
(12, '2', 'Fatima Ahmad', 'fatimaahmad123', '12345'),
(13, '1', 'Ali Asad', 'aliasad123', '12345'),
(14, '2', 'Maham', 'maham123', '12345');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`app_id`);

--
-- Indexes for table `enr`
--
ALTER TABLE `enr`
  ADD PRIMARY KEY (`enr_id`);

--
-- Indexes for table `nurse`
--
ALTER TABLE `nurse`
  ADD PRIMARY KEY (`nurse_id`);

--
-- Indexes for table `org`
--
ALTER TABLE `org`
  ADD PRIMARY KEY (`org_id`);

--
-- Indexes for table `pat`
--
ALTER TABLE `pat`
  ADD PRIMARY KEY (`pat_id`);

--
-- Indexes for table `patientcondition`
--
ALTER TABLE `patientcondition`
  ADD PRIMARY KEY (`pc_id`);

--
-- Indexes for table `stu`
--
ALTER TABLE `stu`
  ADD PRIMARY KEY (`stu_id`);

--
-- Indexes for table `user_role`
--
ALTER TABLE `user_role`
  ADD PRIMARY KEY (`role_id`);

--
-- Indexes for table `user_session`
--
ALTER TABLE `user_session`
  ADD PRIMARY KEY (`session_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `app_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `enr`
--
ALTER TABLE `enr`
  MODIFY `enr_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `nurse`
--
ALTER TABLE `nurse`
  MODIFY `nurse_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `org`
--
ALTER TABLE `org`
  MODIFY `org_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `pat`
--
ALTER TABLE `pat`
  MODIFY `pat_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `patientcondition`
--
ALTER TABLE `patientcondition`
  MODIFY `pc_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `stu`
--
ALTER TABLE `stu`
  MODIFY `stu_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `user_role`
--
ALTER TABLE `user_role`
  MODIFY `role_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `user_session`
--
ALTER TABLE `user_session`
  MODIFY `session_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
