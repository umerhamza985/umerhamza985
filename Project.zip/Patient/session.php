<?php
   include('config.php');
   session_start();
   
   $user_check = $_SESSION['session_username'];
   
   $ses_sql = mysqli_query($db,"select user_session from admin where session_username = '$user_check' ");
   
   $row = mysqli_fetch_array($ses_sql,MYSQLI_ASSOC);
   
   $login_session = $row['session_username'];
   
   if(!isset($_SESSION['session_username'])){
      header("location:login.php");
      die();
   }
?>